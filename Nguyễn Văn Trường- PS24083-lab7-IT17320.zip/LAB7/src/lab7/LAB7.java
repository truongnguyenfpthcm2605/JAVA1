
package lab7;


public class LAB7 {

    public static void main(String[] args) {
       ChuNhat cn = new ChuNhat(5, 7);
       cn.xuat();
       ChuNhat cn2 = new ChuNhat(4, 6);
        cn2.xuat();
        cn = new Vuong(5);
        cn.xuat();
    }
    
}
