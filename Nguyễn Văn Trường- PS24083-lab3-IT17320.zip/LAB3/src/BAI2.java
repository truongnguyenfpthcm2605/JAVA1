// BANG CUU CHUONG
// nguyen van truong ps24083
// ngay tao 8/1/2022
// bai 2 lab3

public class BAI2 {

    public static void main(String[] args) {

        for (int i = 1; i <= 10; i++) {
            for (int j = 1; j <= 10; j++) {
                System.out.printf("%2d * %2d = % 2d\t", j, i, j * i);
            }
            System.out.printf("\n");

        }

    }

}
