
import java.util.Scanner;

public class menu {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choose;
        
        String text;
        do {

            System.out.println("____________________Menu______________________________________________");
            System.out.println("\t1.Nhap danh sach sinh vien tu ban phim");
            System.out.println("\t2.Xuat danh sach sinh vien ra man hinh");
            System.out.println("\t3.Tim va hien thi nhan vien theo ma nhap tu ban phim");
            System.out.println("\t4.Xoa nhan vien theo ma nhap tu ban phim");
            System.out.println("\t5.Cap nhat thong tin nhan vien theo ma nhap tu ban phim");
            System.out.println("\t6.Tim cac nhan vien theo khoang luong nhap va tu ban phim");
            System.out.println("\t7.Sap xep nhan vien theo ho va ten");
            System.out.println("\t8.Sap xep nhan vien theo thu nhap ");
            System.out.println("\t9.Xuat 5 nhan vien co thu nhap cao nhat");
            System.out.println("\t10.Thoat chuong trinh");
            System.out.println("______________________________________________________________________");
            System.out.print("chon chuc nang tu 1 - 10: ");
            choose = sc.nextInt();

            switch (choose) {
                case 1:
                    nhap();
                    break;
                case 2:
                    xuat();
                    ;
                    break;
                case 3:
                    timTheoMa();
                    break;
                case 4:
                    xoaTheoMa();
                    break;
                case 5:
                    capNhatThongTin();
                    break;
                case 6:
                    timTheoLuong();
                    break;
                case 7:
                    SXhoTen();
                    break;
                case 8:
                    SxthuNhap();
                    break;
                case 9:
                    thuNhapCaoNhat();
                    break;
                case 10:
                    sc = new Scanner(System.in);
                    System.out.println("Ban co chat muon thoat khong, nhap 'y' de thoat");
                    text = sc.nextLine();
                    if (text.equalsIgnoreCase("y")) {
                        System.out.println("SEE YOU AGAIN ");
                        System.exit(0);
                    }

                    break;

            }
        } while (choose < 0 || choose >= 10);

    }

    public  static void nhap() {
        System.out.println("\t1.Nhap danh sach sinh vien tu ban phim");
    }

    public static void xuat() {
        System.out.println("\t2.Xuat danh sach sinh vien ra man hinh");
    }

    public  static void timTheoMa() {
        System.out.println("\t3.Tim va hien thi nhan vien theo ma nhap tu ban phim");
    }

    public static void xoaTheoMa() {
        System.out.println("\t4.Xoa nhan vien theo ma nhap tu ban phim");
    }

    public static void capNhatThongTin() {
        System.out.println("\t5.Cap nhat thong tin nhan vien theo ma nhap tu ban phim");
    }

    public static  void timTheoLuong() {
        System.out.println("\t6.Tim cac nhan vien theo khoang luong nhap va tu ban phim");
    }

    public static void SXhoTen() {
        System.out.println("\t7.Sap xep nhan vien theo ho va ten");
    }

    public static void SxthuNhap() {
        System.out.println("\t8.Sap xep nhan vien theo thu nhap ");
    }

    public static void thuNhapCaoNhat() {
        System.out.println("\t9.Xuat 5 nhan vien co thu nhap cao nhat");
    }

}
